package com.example.service;


import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;

import com.example.entity.Category;
import com.example.repository.CategoryRepository;

class CategoryServiceTest {

    @Mock
    private CategoryRepository categoryRepository;

    @InjectMocks
    private CategoryServiceImp categoryService;

    @BeforeEach
    void setUp() {
        MockitoAnnotations.openMocks(this);
    }

    @Test
    void getAllCategories() {
        // Given
        List<Category> categories = new ArrayList<>();
        categories.add(new Category());
        categories.add(new Category());
        when(categoryRepository.findAll()).thenReturn(categories);

        // When
        List<Category> result = categoryService.getAllCategories();

        // Then
        assertEquals(categories.size(), result.size());
    }

    @Test
    void getCategoryById() {
        // Given
        Category category = new Category();
        when(categoryRepository.findById(1L)).thenReturn(Optional.of(category));

        // When
        Category result = categoryService.getCategoryById(1L);

        // Then
        assertEquals(category.getName(), result.getName());
    }

    @Test
    void createCategory() {
        // Given
        Category category = new Category();
        when(categoryRepository.save(any())).thenReturn(category);

        // When
        Category result = categoryService.createCategory(category);

        // Then
        assertEquals(category.getName(), result.getName());
    }

    @Test
    void updateCategory() {
        // Given
        Category existingCategory = new Category();
        Category updatedCategory = new Category();
        when(categoryRepository.findById(1L)).thenReturn(Optional.of(existingCategory));
        when(categoryRepository.save(any())).thenReturn(updatedCategory);

        // When
        Category result = categoryService.updateCategory(1L, updatedCategory);

        // Then
        assertEquals(updatedCategory.getName(), result.getName());
        assertEquals(updatedCategory.getDescription(), result.getDescription());
    }

    @Test
    void deleteCategory() {
        // When
        categoryService.deleteCategory(1L);

        // Then
        verify(categoryRepository, times(1)).deleteById(1L);
    }
}

